/**
 * Class creating an Spacecraft Object  
 * @author Darren Buck pjx598
 *
 */
public class Spacecraft {

	private String name;
	private String type;
	private int number;
	/**
	 * Constructor that takes in information regarding the spacecraft
	 * -spacecraft name
	 * -spacecraft type
	 * -spacecraft number
	 * @param name
	 * @param type
	 * @param number
	 */
	public Spacecraft(String name, String type, int number) {
		this.name = name;
		this.type = type;
		this.number = number;
	}
	/**
	 * Sets spacecraft name
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * Returns spacecraft name
	 * @return
	 */
	public String getName() {
		return name;
	}
	/**
	 * Sets spacecraft type
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * Returns spacecraft type
	 * @return
	 */
	public String getType() {
		return type;
	}
	/**
	 * Sets spacecraft number
	 * @param number
	 */
	public void setNumber(int number) {
		this.number = number;
	}
	/**
	 * Returns spacecraft number
	 * @return
	 */
	public int getNumber() {
		return number;
	}
	/**
	 * Returns a string containing Spacecraft details
	 * @return
	 */
	public String toString() {
		return String.format("    %s(%d) : %s%n",this.type,this.number,this.name);
	}
}
