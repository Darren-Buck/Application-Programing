/**
 * Class to create an Object Astronaut containing details regarding crew member
 * @author Darren Buck pjx598
 *
 */
public class Astronaut {

	private String name;
	private String position;
	/**
	 * Constructor for Astronaut that takes in 
	 * -Astronaut name
	 * -Astronaut position
	 * @param name
	 * @param position
	 */
	public Astronaut(String name, String position) {
		this.name = name;
		this.position = position;
	}
	/**
	 * Sets astronaut name
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * Returns astronaut name
	 * @return
	 */
	public String getName() {
		return name;
	}
	/**
	 * Sets astronaut position
	 * @param position
	 */
	public void setPosition(String position) {
		this.position = position;
	}
	/**
	 * Returns astronaut position
	 * @return
	 */
	public String getPosition() {
		return position;
	}
	/**
	 * Returns a string containing Astronaut details
	 * @return
	 */
	public String toString() {
		return String.format("    %s : %s%n",this.position,this.name);
	}
	
}
