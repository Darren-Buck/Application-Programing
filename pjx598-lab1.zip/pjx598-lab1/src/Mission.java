/**
 * 
 * @author Darren Buck pjx598
 * This class sets up the Mission details and combines all information
 * regarding the mission
 *
 */
public class Mission {

	private String name;
	private String operator;
	private int year;
	private String type;
	private Spacecraft[] spacecrafts = new Spacecraft[100];
	private Astronaut[] crewMembers = new Astronaut[100];
	private int i = 0;
	private int j = 0;
	private String output;
	/**
	 * 
	 * @param name
	 * @param operator
	 * @param year
	 * @param type
	 * 
	 * This is the constructor to create a mission
	 * takes in the
	 * -mission name
	 * -operator name
	 * -year of mission
	 * -type of mission
	 */
	public Mission(String name, String operator, int year, String type) {
		this.name = name;
		this.operator = operator;
		this.year = year;
		this.type = type;
	}
	/**
	 * Sets mission name
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * Returns mission name
	 * @return
	 */
	public String getName() {
		return name;
	}
	/**
	 * Sets operator name
	 * @param operator
	 */
	public void setOperator(String operator) {
		this.operator = operator;
	}
	/**
	 * Returns operator name
	 * @return
	 */
	public String getOperator() {
		return operator;
	}
	/**
	 * Sets year of mission
	 * @param year
	 */
	public void setYear(int year) {
		this.year = year;
	}
	/**
	 * Returns year of mission
	 * @return
	 */
	public int getYear() {
		return year;
	}
	/**
	 * Sets mission type
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * Returns mission type
	 * @return
	 */
	public String getType() {
		return type;
	}
	/**
	 * Adds Spacecraft object to an array of Spacecraft objects
	 * @param spacecraft
	 */
	public void addSpacecraft(Spacecraft spacecraft) {
		this.spacecrafts[i] = spacecraft;
		i++;
	}
	/**
	 * Adds Astronaut object to an array of Astronaut objects
	 * @param crew
	 */
	public void addCrewMember(Astronaut crew) {
		this.crewMembers[j] = crew;
		j++;
	}
	/**
	 *Returns a constructed output string containing 
	 *all mission data
	 *@return
	 */
	public String toString() {
		output = String.format("%s (%s)%n   %s, %d%n   Spacecrafts:%n",
				this.name,this.operator,this.type,this.year);
		for(int k = 0;k<spacecrafts.length;k++) {
			if (spacecrafts[k] != null) {
			output = output + spacecrafts[k];
			}
		}
		output = output + String.format("   Crew:%n");
		for(int k = 0;k<crewMembers.length;k++) {
			if (crewMembers[k] != null) {
			output = output + crewMembers[k];
			}
		}
		
		return output;
		
	}
	
}
