/**
 * Class to create an address book object 
 * @author Darren Buck pjx598
 */
import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class AddressBook {

	private String bookName;
	private Contact[] contact = new Contact[100];
	private int i = 0;
	
	/**
	 * Constructor for AddressBook that takes in
	 * - bookName
	 * @param bookName
	 */
	public AddressBook(String bookName) {
		this.bookName = bookName;
	}
	/**
	 * Sets bookName
	 * @param bookName
	 */
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	/**
	 * Returns bookName
	 * @return
	 */
	public String getBookName() {
		return bookName;
	}
	/**
	 * Method to add Contact object to an array of Contact objects
	 * @param contact
	 */
	public void addContact(Contact contact) {
		this.contact[i] = contact;
		i++;
	}
	/**
	 * Method to read a file and assign contents to designated 
	 * attributes of specific Contact type
	 * @param fileName
	 */
	public void loadContacts(String fileName) {
		try {
			File file = new File( fileName );
			Scanner scan = new Scanner( file );
				while(scan.hasNext()) {
					String line = scan.nextLine();
					String[] items = line.split(",");
					
					if(items.length == 4) {
						
						String name = items[0].trim();
						String relationship = items[1].trim();
						String phoneNumber = items[2].trim();
						String location = items[3].trim();
						
						Contact contact = new FamilyMember(name,relationship,phoneNumber,location);
						addContact(contact);
					}
					else if(items.length == 3) {
						
						String name = items[0].trim();
						String title = items[1].trim();
						String phoneNumber = items[2].trim();
						
						
						Contact contact = new WorkContact(name,title,phoneNumber);
						addContact(contact);
				}
			}
			scan.close();
		}catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	/**
	 * Returns a formated string to print Contacts in book
	 * @return
	 */
	public String toString() {
		i = 0;
		String output;
		output = String.format("%s%n---------------%n",this.bookName);
		while (contact[i] != null) {
			output = output + String.format("%s%n",contact[i]);
		i++;
		}
		return output;
	}
}
