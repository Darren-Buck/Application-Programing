/**
 * Class to define a Family Member object extends(is a type of) Contact 
 * @author Darren Buck pjx598
 */
public class FamilyMember extends Contact{

	private String relationship;
	private String location;
	/**
	 * Constructor that takes in attributes of FamilyMember
	 * @param name
	 * @param relationship
	 * @param phoneNumber
	 * @param location
	 */
	public FamilyMember(String name, String relationship,String phoneNumber, String location) {
		super (name,phoneNumber);
		this.relationship = relationship;
		this.location = location;
	}
	/**
	 * Sets relationship
	 * @param relationship
	 */
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	/**
	 * Returns relationship
	 * @return
	 */
	public String getRelationship() {
		return relationship;
	}
	/**
	 * Sets location
	 * @param location
	 */
	public void setLocation(String location) {
		this.location = location;
	}
	/**
	 * Returns location
	 * @return
	 */
	public String getLocation() {
		return location;
	}
	/**
	 * Returns a formated string that is stored in the Contact array 
	 * @return
	 */
	public String toString() {
		return String.format("- %s (%s, %s): %s%n",this.getName(),this.relationship,this.location, this.getPhoneNumber());
	}
	
}
