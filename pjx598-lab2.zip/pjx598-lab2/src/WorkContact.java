/**
 * Class to create an object WorkContact extends(is a type of) Contact
 * @author Darren Buck pjx598
 *
 */
public class WorkContact extends Contact {

	private String title;
	/**
	 * Constructor to take in attributes for WorkContact
	 * @param name
	 * @param phoneNumber
	 * @param title
	 */
	public WorkContact(String name, String phoneNumber,String title) {
		super(name,phoneNumber);
		this.title = title;
	}
	/**
	 * Sets title 
	 * @param title
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * Returns title
	 * @return
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * Returns a formated string that is stored in the Contact array 
	 * @return
	 */
	public String toString() {
		return String.format(("- %s (%s): %s%n"),this.getName(),this.title,this.getPhoneNumber());
	}
}
