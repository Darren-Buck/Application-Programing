/**
 * Abstract class to define a Contact object 
 * @author Darren Buck pjx598
 */
public abstract class Contact {

	private String name;
	private String phoneNumber;
	/**
	 * Constructor that takes in name and number for 
	 * base Contact information
	 * @param name
	 * @param phoneNumber
	 */
	public Contact(String name, String phoneNumber) {
		this.name = name;
		this.phoneNumber = phoneNumber;
	}
	/**
	 * Sets name
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * Returns name
	 * @return
	 */
	public String getName() {
		return name;
	}
	/**
	 * Sets phone number
	 * @param phoneNumber
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	/**
	 * Returns phone number
	 * @return
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}
}
